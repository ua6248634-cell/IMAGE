#!/bin/bash
# Shaurya OS — Write to USB
[ "$(id -u)" -ne 0 ] && exec sudo bash "$0" "$@"
ISO=$(find . output/ -name "*.iso" 2>/dev/null | head -1)
[ -z "$ISO" ] && { echo "No ISO! Run: bash START.sh first"; exit 1; }
echo "ISO: $ISO ($(du -sh $ISO | awk '{print $1}'))"
[ -z "$1" ] && { echo "Usage: sudo bash WRITE-USB.sh /dev/sdX"; lsblk; exit 0; }
read -p "⚠️  ERASE $1? Type YES: " c
[ "$c" != "YES" ] && exit 0
dd if="$ISO" of="$1" bs=4M status=progress oflag=sync && echo "✅ Done!"
