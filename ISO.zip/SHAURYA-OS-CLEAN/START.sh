#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║  SHAURYA OS v1.0 — BUILD SCRIPT                               ║
# ║  Installable ISO — installs to hard disk                       ║
# ║  Creator: Usman Ahmad                                           ║
# ╚══════════════════════════════════════════════════════════════════╝
RED='\033[0;31m'; GRN='\033[0;32m'
YLW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}"
cat << 'BANNER'
  ███████╗██╗  ██╗ █████╗ ██╗   ██╗██████╗ ██╗   ██╗ █████╗
  ██╔════╝██║  ██║██╔══██╗██║   ██║██╔══██╗╚██╗ ██╔╝██╔══██╗
  ███████╗███████║███████║██║   ██║██████╔╝ ╚████╔╝ ███████║
  ╚════██║██╔══██║██╔══██║██║   ██║██╔══██╗  ╚██╔╝  ██╔══██║
  ███████║██║  ██║██║  ██║╚██████╔╝██║  ██║   ██║   ██║  ██║
  ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝
BANNER
echo -e "${YLW}  ⚔️  Shaurya OS v1.0 — Courage in Every Byte${NC}"
echo -e "${CYAN}  Creator: Usman Ahmad${NC}"
echo ""

# Root check
[ "$(id -u)" -ne 0 ] && exec sudo bash "$0" "$@"

# Fix spaces in path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
cd "$SCRIPT_DIR"
if echo "$(pwd)" | grep -q ' '; then
    SAFE="/tmp/shaurya-build"
    rm -rf "$SAFE"; cp -r "$(pwd)" "$SAFE"; cd "$SAFE"
    echo -e "${GRN}[✓] Moved to: $SAFE${NC}"
fi

BUILD_DIR="$(pwd)"
OUTPUT_DIR="$BUILD_DIR/output"
mkdir -p "$OUTPUT_DIR"

# ── Suppress kernel prompts ────────────────────────────────────
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
export NEEDRESTART_SUSPEND=1
mkdir -p /etc/needrestart/conf.d/
printf '$nrconf{restart} = '"'"'a'"'"';\n$nrconf{kernelhints} = 0;\n' \
    > /etc/needrestart/conf.d/99-auto.conf 2>/dev/null || true
printf '#!/bin/bash\nexit 0\n' > /usr/sbin/needrestart 2>/dev/null || true
chmod +x /usr/sbin/needrestart 2>/dev/null || true

# ── Fix mirror — ftp.debian.org prevents download errors ───────
echo -e "${CYAN}[*] Setting ftp.debian.org mirror...${NC}"
cat > /etc/apt/sources.list << 'SRC'
deb http://ftp.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://ftp.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
deb http://ftp.debian.org/debian bookworm-backports main contrib non-free non-free-firmware
SRC

# Remove Kali/Parrot repos from host
rm -f /etc/apt/sources.list.d/kali*.list   2>/dev/null || true
rm -f /etc/apt/sources.list.d/parrot*.list 2>/dev/null || true

# ── Fix PAM ────────────────────────────────────────────────────
DEBIAN_FRONTEND=noninteractive dpkg-reconfigure libpam-runtime 2>/dev/null || true

# ── APT speed ──────────────────────────────────────────────────
cat > /etc/apt/apt.conf.d/99-shaurya-build << 'APTEOF'
Acquire::Retries "10";
Acquire::http::Timeout "120";
Acquire::http::Pipeline-Depth "5";
APT::Install-Recommends "false";
Acquire::Languages "none";
APTEOF

# ── Install dependencies ───────────────────────────────────────
echo -e "${CYAN}[*] Installing live-build...${NC}"
apt-get update -qq 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    live-build debootstrap xorriso squashfs-tools \
    grub-pc-bin grub-efi-amd64-bin mtools \
    syslinux syslinux-common isolinux \
    rsync curl wget git ca-certificates \
    gnupg python3 python3-pip \
    libpam-runtime passwd 2>/dev/null || true
echo -e "${GRN}[✓] live-build ready${NC}"

# ── Permissions ────────────────────────────────────────────────
chmod +x START.sh auto/config 2>/dev/null || true
find config/hooks -name "*.chroot" -exec chmod +x {} \; 2>/dev/null || true

# ── Configure & Build ──────────────────────────────────────────
echo -e "${CYAN}[*] Cleaning...${NC}"
lb clean --purge 2>/dev/null || true

echo -e "${CYAN}[*] Configuring...${NC}"
bash auto/config
echo -e "${GRN}[✓] Config OK${NC}"

# Set archive mirrors
mkdir -p config/archives
cat > config/archives/shaurya.list.chroot << 'MIR'
deb http://ftp.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://ftp.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
MIR
cat > config/archives/shaurya.list.binary << 'MIR'
deb http://ftp.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
MIR

echo ""
echo -e "${YLW}╔══════════════════════════════════════════════════════════════╗"
echo -e "║  ⚔️  BUILDING SHAURYA OS v1.0 — INSTALLABLE ISO             ║"
echo -e "║  Creator: Usman Ahmad | Time: 3-5 hours                    ║"
echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

START_T=$(date +%s)
lb build 2>&1 | tee "$OUTPUT_DIR/build.log"
END_T=$(date +%s)
ELAPSED=$(( END_T - START_T ))

# Find ISO
ISO=""
for p in "*.hybrid.iso" "live-image-amd64.hybrid.iso" "*.iso"; do
    f=$(find "$BUILD_DIR" -maxdepth 3 -name "$p" 2>/dev/null | \
        while read x; do [ -s "$x" ] && echo "$x"; done | head -1)
    [ -n "$f" ] && { ISO="$f"; break; }
done

if [ -n "$ISO" ]; then
    DEST="$OUTPUT_DIR/Shaurya-OS-v1.0-amd64.iso"
    [ "$ISO" != "$DEST" ] && cp "$ISO" "$DEST"
    echo ""
    echo -e "${GRN}╔══════════════════════════════════════════════════════════════╗"
    echo -e "║  ⚔️  SHAURYA OS v1.0 — BUILD COMPLETE!                      ║"
    echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  ${GRN}ISO   :${NC} $DEST"
    echo -e "  ${GRN}Size  :${NC} $(du -sh "$DEST" | awk '{print $1}')"
    echo -e "  ${GRN}MD5   :${NC} $(md5sum "$DEST" | awk '{print $1}')"
    echo -e "  ${GRN}Time  :${NC} ${ELAPSED}s ($(( ELAPSED/60 ))min)"
    echo ""
    echo -e "  ${YLW}Write USB :${NC} sudo dd if=$DEST of=/dev/sdX bs=4M status=progress"
    echo -e "  ${YLW}VM test   :${NC} qemu-system-x86_64 -m 4096 -enable-kvm -cdrom $DEST -boot d"
    echo -e "  ${YLW}Login     :${NC} shaurya / usman141093"
else
    echo -e "${RED}BUILD FAILED — Log: $OUTPUT_DIR/build.log${NC}"
    tail -30 "$OUTPUT_DIR/build.log" 2>/dev/null
    exit 1
fi
